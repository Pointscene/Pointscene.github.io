import * as React from 'react';
import { FC } from 'react';

interface Coord3D {
    x: number;
    y: number;
    z: number;
}
interface WorldProps {
    domEl: HTMLElement;
    fitTopView?: boolean;
    camera?: Coord3D;
    look?: Coord3D;
    children?: React.ReactNode;
    disableTelemetry?: boolean;
    disableQueryParams?: boolean;
    proj4?: string;
}
declare const WorldFC: FC<WorldProps>;

interface PointCloudProps {
    url: string;
    name: string;
}
declare const PointCloudFC: FC<PointCloudProps>;

interface InitUIOpts {
    disableControls?: boolean;
    disableLayers?: boolean;
    disablePointclouds?: boolean;
    disableMeasure?: boolean;
    disableShare?: boolean;
    domElId?: string;
}

interface UiProps extends InitUIOpts {
}
declare const UiFC: FC<UiProps>;

interface TmsProps {
    url: string;
    isTms?: boolean;
    bounds?: number[][];
}
declare const TmsFC: FC<TmsProps>;

export { PointCloudFC as PointCloud, TmsFC as TileMapService, UiFC as UI, WorldFC as World };
